import React, { useEffect } from 'react';
import { Users, Award, Target, Clock } from 'lucide-react';
import CallToAction from '../components/CallToAction';

const AboutPage = () => {
  useEffect(() => {
    // Set page title
    document.title = 'About Us - VirtualAssist';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  const values = [
    {
      icon: <Users className="w-10 h-10 text-teal-600" />,
      title: 'Client-Centered',
      description: 'We put our clients at the center of everything we do, tailoring our services to meet your specific needs.',
    },
    {
      icon: <Award className="w-10 h-10 text-teal-600" />,
      title: 'Excellence',
      description: 'We strive for excellence in every task, delivering high-quality work that exceeds expectations.',
    },
    {
      icon: <Target className="w-10 h-10 text-teal-600" />,
      title: 'Precision',
      description: 'We pay attention to the smallest details, ensuring accuracy and precision in all our work.',
    },
    {
      icon: <Clock className="w-10 h-10 text-teal-600" />,
      title: 'Reliability',
      description: 'We deliver on time, every time, because we understand the importance of deadlines.',
    },
  ];

  const team = [
    {
      name: 'Sarah Johnson',
      title: 'Founder & CEO',
      image: 'https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      bio: 'With over 15 years of experience in business management, Sarah founded VirtualAssist to help entrepreneurs focus on their core business.',
    },
    {
      name: 'David Chen',
      title: 'Operations Director',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      bio: 'David ensures the smooth operation of all our services and makes sure clients receive consistent quality across all departments.',
    },
    {
      name: 'Amanda Rivera',
      title: 'Client Success Manager',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      bio: 'Amanda works closely with clients to understand their needs and ensure our virtual assistance solutions align with their goals.',
    },
    {
      name: 'Michael Patel',
      title: 'Technical Director',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      bio: 'Michael leads our tech-focused services, bringing expertise in web design, SEO, and digital marketing to our clients.',
    },
  ];

  return (
    <div>
      {/* Header Section */}
      <section className="bg-navy-900 text-white pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About VirtualAssist</h1>
            <p className="text-xl text-gray-300">
              We're a team of dedicated professionals committed to helping businesses thrive by providing exceptional virtual assistance services.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6">Our Story</h2>
              <p className="text-gray-600 mb-4">
                VirtualAssist was founded in 2020 with a simple mission: to help entrepreneurs and small businesses focus on what they do best by handling the time-consuming administrative, creative, and technical tasks that consume valuable time and energy.
              </p>
              <p className="text-gray-600 mb-4">
                Our founder, Sarah Johnson, experienced firsthand the challenges of trying to do it all while growing a business. She realized that many entrepreneurs were in the same position—experts in their field but stretched thin by the demands of running a business.
              </p>
              <p className="text-gray-600">
                What started as a small team offering basic administrative support has grown into a comprehensive virtual assistance agency with experts across multiple disciplines, from accounting and SEO to graphic design and project management.
              </p>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/3153198/pexels-photo-3153198.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Our Team Working" 
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-teal-600 w-32 h-32 rounded-lg flex items-center justify-center text-white">
                <div className="text-center">
                  <div className="text-3xl font-bold">5+</div>
                  <div className="text-sm">Years of<br/>Excellence</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">Our Values</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              These core values guide everything we do at VirtualAssist. They're the foundation of our company culture and the promises we make to our clients.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-teal-100 mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Meet Our Team Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">Meet Our Leadership Team</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Get to know the dedicated professionals who lead our virtual assistance agency.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden group">
                <div className="h-64 overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-navy-900 mb-1">{member.name}</h3>
                  <p className="text-teal-600 font-medium mb-3">{member.title}</p>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CallToAction />
    </div>
  );
};

export default AboutPage;