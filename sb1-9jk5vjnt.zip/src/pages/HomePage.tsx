import React, { useEffect } from 'react';
import Hero from '../components/Hero';
import FeaturedServices from '../components/FeaturedServices';
import AboutSection from '../components/AboutSection';
import Testimonials from '../components/Testimonials';
import CallToAction from '../components/CallToAction';
import Stats from '../components/Stats';

const HomePage = () => {
  useEffect(() => {
    // Set page title
    document.title = 'VirtualAssist - Your One-Stop Virtual Assistance Agency';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <Hero />
      <FeaturedServices />
      <AboutSection />
      <Stats />
      <Testimonials />
      <CallToAction />
    </div>
  );
};

export default HomePage;