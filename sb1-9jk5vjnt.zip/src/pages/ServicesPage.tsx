import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import ServiceCard from '../components/ServiceCard';
import CallToAction from '../components/CallToAction';
import { services } from '../data/services';

const ServicesPage = () => {
  useEffect(() => {
    // Set page title
    document.title = 'Our Services - VirtualAssist';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Header Section */}
      <section className="bg-navy-900 text-white pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-gray-300">
              We offer a comprehensive range of virtual assistance services to help your business thrive. Focus on what you do best and let us handle the rest.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* How We Work Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">How We Work</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We follow a simple but effective process to ensure you receive the highest quality service that meets your specific needs.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="relative">
              <div className="bg-white p-6 rounded-lg shadow-md text-center h-full">
                <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center text-xl font-bold mx-auto mb-4">1</div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">Consultation</h3>
                <p className="text-gray-600">We start with a detailed consultation to understand your business needs and goals.</p>
              </div>
              <div className="hidden md:block absolute top-1/2 left-full transform -translate-y-1/2 w-12 h-2 bg-teal-600 -ml-1"></div>
            </div>
            
            <div className="relative">
              <div className="bg-white p-6 rounded-lg shadow-md text-center h-full">
                <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center text-xl font-bold mx-auto mb-4">2</div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">Custom Plan</h3>
                <p className="text-gray-600">We create a tailored service plan based on your specific requirements.</p>
              </div>
              <div className="hidden md:block absolute top-1/2 left-full transform -translate-y-1/2 w-12 h-2 bg-teal-600 -ml-1"></div>
            </div>
            
            <div className="relative">
              <div className="bg-white p-6 rounded-lg shadow-md text-center h-full">
                <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center text-xl font-bold mx-auto mb-4">3</div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">Implementation</h3>
                <p className="text-gray-600">Our team of experts implements the plan with precision and attention to detail.</p>
              </div>
              <div className="hidden md:block absolute top-1/2 left-full transform -translate-y-1/2 w-12 h-2 bg-teal-600 -ml-1"></div>
            </div>
            
            <div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center h-full">
                <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center text-xl font-bold mx-auto mb-4">4</div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">Review & Refine</h3>
                <p className="text-gray-600">We regularly review progress and refine our approach to ensure optimal results.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Here are answers to some common questions about our virtual assistance services.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-navy-900 mb-2">How do you ensure quality and consistency?</h3>
                <p className="text-gray-600">
                  We assign a dedicated team to your account, led by an account manager who ensures consistent quality across all services. We also have rigorous quality control processes in place.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-navy-900 mb-2">Can I scale services up or down as needed?</h3>
                <p className="text-gray-600">
                  Absolutely! Our service plans are flexible and can be adjusted as your business needs change. We offer month-to-month agreements with no long-term commitments.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-navy-900 mb-2">How do we communicate with your team?</h3>
                <p className="text-gray-600">
                  We use a variety of communication tools including email, phone, video calls, and project management software. Your preferences determine how we communicate.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-navy-900 mb-2">What is your typical turnaround time?</h3>
                <p className="text-gray-600">
                  Turnaround times vary depending on the service and project scope. We'll provide detailed timelines during the consultation phase and always keep you updated on progress.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-navy-900 mb-2">Do you offer custom service packages?</h3>
                <p className="text-gray-600">
                  Yes, we create custom service packages tailored to your specific business needs. Contact us for a consultation to discuss your requirements.
                </p>
              </div>
            </div>
            
            <div className="text-center mt-10">
              <p className="text-gray-600 mb-4">Don't see your question here?</p>
              <Link 
                to="/contact" 
                className="inline-flex items-center justify-center px-6 py-3 rounded-md bg-navy-800 text-white hover:bg-navy-900 transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>

      <CallToAction />
    </div>
  );
};

export default ServicesPage;