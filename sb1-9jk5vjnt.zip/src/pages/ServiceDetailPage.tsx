import React, { useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { Check, ArrowRight } from 'lucide-react';
import { services } from '../data/services';
import { Service } from '../types/Service';
import CallToAction from '../components/CallToAction';

interface ServiceDetailPageProps {
  serviceId?: string;
}

const ServiceDetailPage: React.FC<ServiceDetailPageProps> = ({ serviceId }) => {
  const params = useParams();
  const navigate = useNavigate();
  const slug = params.slug || '';
  
  // Find the service either by ID or by slug
  const service = serviceId 
    ? services.find(s => s.id === serviceId)
    : services.find(s => s.slug === slug);
  
  useEffect(() => {
    // If service not found, redirect to services page
    if (!service) {
      navigate('/services');
      return;
    }

    // Set page title
    document.title = `${service.title} - VirtualAssist`;
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, [service, navigate]);
  
  if (!service) return null;
  
  // Find related services (excluding current service)
  const relatedServices = services
    .filter(s => s.id !== service.id)
    .slice(0, 3);
  
  return (
    <div>
      {/* Header Section */}
      <section className="bg-navy-900 text-white pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">{service.title}</h1>
            <p className="text-xl text-gray-300">
              {service.shortDescription}
            </p>
          </div>
        </div>
      </section>

      {/* Service Overview */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6">Overview</h2>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <div className="space-y-4 mb-8">
                {service.benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <div className="mr-3 mt-1">
                      <Check className="w-5 h-5 text-teal-600" />
                    </div>
                    <p className="text-gray-700">{benefit}</p>
                  </div>
                ))}
              </div>
              <Link 
                to="/contact" 
                className="inline-flex items-center justify-center px-6 py-3 rounded-md bg-teal-600 text-white hover:bg-teal-700 transition-colors"
              >
                Get Started
                <ArrowRight size={16} className="ml-2" />
              </Link>
            </div>
            <div>
              <img 
                src={service.image} 
                alt={service.title} 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">Our {service.title} Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We follow a structured approach to deliver exceptional {service.title.toLowerCase()} services.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {service.process.map((step, index) => (
                <div key={index} className="flex flex-col md:flex-row items-start md:items-center gap-6">
                  <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center text-xl font-bold flex-shrink-0">
                    {index + 1}
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md flex-grow">
                    <h3 className="text-xl font-bold text-navy-900 mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">Pricing Plans</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Choose the plan that fits your business needs. Not sure which plan is right for you? Contact us for a custom quote.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {service.pricing.map((plan, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-lg shadow-md overflow-hidden ${
                  plan.popular ? 'ring-2 ring-teal-600 transform md:-translate-y-4' : ''
                }`}
              >
                {plan.popular && (
                  <div className="bg-teal-600 text-white text-center py-2 font-medium">
                    Most Popular
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-navy-900 mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-3xl font-bold text-navy-900">${plan.price}</span>
                    <span className="text-gray-600">/{plan.period}</span>
                  </div>
                  <p className="text-gray-600 mb-6">{plan.description}</p>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <Check className="w-5 h-5 text-teal-600 mr-3 mt-1 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link 
                    to="/contact" 
                    className={`block text-center py-3 px-4 rounded-md transition-colors w-full ${
                      plan.popular 
                        ? 'bg-teal-600 text-white hover:bg-teal-700' 
                        : 'bg-navy-800 text-white hover:bg-navy-900'
                    }`}
                  >
                    Select Plan
                  </Link>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Need a custom solution?</p>
            <Link 
              to="/contact" 
              className="inline-flex items-center justify-center px-6 py-3 rounded-md bg-navy-800 text-white hover:bg-navy-900 transition-colors"
            >
              Contact Us for a Custom Quote
            </Link>
          </div>
        </div>
      </section>

      {/* Related Services */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">Related Services</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore other services that complement {service.title.toLowerCase()} to maximize your business potential.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {relatedServices.map((relatedService) => (
              <div key={relatedService.id} className="bg-white rounded-lg shadow-md overflow-hidden group">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={relatedService.image} 
                    alt={relatedService.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-navy-900 mb-2">{relatedService.title}</h3>
                  <p className="text-gray-600 mb-4">{relatedService.shortDescription}</p>
                  <Link 
                    to={`/services/${relatedService.slug}`} 
                    className="inline-flex items-center text-teal-600 font-medium hover:text-teal-700"
                  >
                    Learn More
                    <ArrowRight size={16} className="ml-2 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CallToAction />
    </div>
  );
};

export default ServiceDetailPage;