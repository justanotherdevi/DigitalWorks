import React, { useEffect } from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import ContactForm from '../components/ContactForm';

const ContactPage = () => {
  useEffect(() => {
    // Set page title
    document.title = 'Contact Us - VirtualAssist';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Header Section */}
      <section className="bg-navy-900 text-white pt-32 pb-16 md:pt-40 md:pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl text-gray-300">
              Have questions or ready to get started? Reach out to our team and we'll be happy to help.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info & Form Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h2 className="text-3xl font-bold text-navy-900 mb-6">Get in Touch</h2>
              <p className="text-gray-600 mb-8">
                We're here to answer your questions and discuss how our virtual assistance services can help your business grow. Reach out using any of the methods below.
              </p>
              
              <div className="space-y-6 mb-8">
                <div className="flex items-start">
                  <div className="bg-teal-100 p-3 rounded-full mr-4">
                    <MapPin className="w-6 h-6 text-teal-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-navy-900 mb-1">Our Office</h3>
                    <p className="text-gray-600">
                      1234 Virtual Street, Suite 500<br />
                      San Francisco, CA 94107
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-teal-100 p-3 rounded-full mr-4">
                    <Phone className="w-6 h-6 text-teal-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-navy-900 mb-1">Phone</h3>
                    <p className="text-gray-600">
                      <a href="tel:+15551234567" className="hover:text-teal-600 transition-colors">
                        (555) 123-4567
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-teal-100 p-3 rounded-full mr-4">
                    <Mail className="w-6 h-6 text-teal-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-navy-900 mb-1">Email</h3>
                    <p className="text-gray-600">
                      <a href="mailto:info@virtualassist.com" className="hover:text-teal-600 transition-colors">
                        info@virtualassist.com
                      </a>
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-teal-100 p-3 rounded-full mr-4">
                    <Clock className="w-6 h-6 text-teal-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-navy-900 mb-1">Hours</h3>
                    <p className="text-gray-600">
                      Monday - Friday: 9:00 AM - 6:00 PM PST<br />
                      Saturday - Sunday: Closed
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="p-6 bg-gray-50 rounded-lg border border-gray-200">
                <h3 className="text-lg font-bold text-navy-900 mb-3">Quick Response Guarantee</h3>
                <p className="text-gray-600">
                  We respond to all inquiries within 24 hours during business days. Your time is valuable, and we're committed to providing prompt, helpful service.
                </p>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <h2 className="text-2xl font-bold text-navy-900 mb-6">Send Us a Message</h2>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-navy-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Have a question? Check our FAQ section for quick answers.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold text-navy-900 mb-2">How quickly can you start working with us?</h3>
                <p className="text-gray-600">
                  We can typically begin working with new clients within 3-5 business days after completing the initial consultation and finalizing the service agreement.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold text-navy-900 mb-2">Do you offer free consultations?</h3>
                <p className="text-gray-600">
                  Yes, we offer a free 30-minute consultation to discuss your needs and how our services can help your business.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold text-navy-900 mb-2">What if I need multiple services?</h3>
                <p className="text-gray-600">
                  We offer custom packages that combine multiple services at discounted rates. Contact us to discuss your specific needs.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold text-navy-900 mb-2">How do billing and payments work?</h3>
                <p className="text-gray-600">
                  We offer monthly subscription plans with payments due at the beginning of each month. We accept all major credit cards and bank transfers.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;