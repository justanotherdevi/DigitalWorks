import { Testimonial } from '../types/Testimonial';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Jason Williams',
    title: 'CEO',
    company: 'TechStart Solutions',
    quote: 'VirtualAssist has been an absolute game-changer for our business. Their accounting services have saved us countless hours and helped us make better financial decisions. Highly recommended!',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
  {
    id: '2',
    name: 'Emily Chen',
    title: 'Marketing Director',
    company: 'GrowthLab',
    quote: 'The social media management team at VirtualAssist has transformed our online presence. Our engagement is up 200% and we\'re seeing real business results from their strategic approach.',
    avatar: 'https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
  {
    id: '3',
    name: 'Marcus Johnson',
    title: 'Founder',
    company: 'EcoVenture',
    quote: 'I was skeptical about hiring virtual assistance, but the web design and SEO services from VirtualAssist have exceeded all my expectations. Our organic traffic has increased by 150% in just three months!',
    avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
  {
    id: '4',
    name: 'Sarah Thompson',
    title: 'Operations Manager',
    company: 'Streamline Retail',
    quote: 'The project management expertise at VirtualAssist has helped us launch three major initiatives on time and under budget. Their organization and communication are exceptional.',
    avatar: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
  {
    id: '5',
    name: 'David Rodriguez',
    title: 'Creative Director',
    company: 'Visual Concepts',
    quote: 'As a creative agency, we have high standards for design work. VirtualAssist\'s graphic design services have consistently delivered outstanding results that impress both us and our clients.',
    avatar: 'https://images.pexels.com/photos/2379873/pexels-photo-2379873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
  {
    id: '6',
    name: 'Michelle Patel',
    title: 'Small Business Owner',
    company: 'Coastal Cuisine',
    quote: 'Running a restaurant keeps me incredibly busy. Having VirtualAssist handle our accounting and social media has been a lifesaver. They\'re like having an extra team member without the overhead.',
    avatar: 'https://images.pexels.com/photos/3767392/pexels-photo-3767392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
  },
];