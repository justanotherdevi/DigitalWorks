import { ReactNode } from 'react';

export interface ServiceProcess {
  title: string;
  description: string;
}

export interface ServicePricing {
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  popular?: boolean;
}

export interface Service {
  id: string;
  title: string;
  slug: string;
  shortDescription: string;
  description: string;
  icon: ReactNode;
  image: string;
  benefits: string[];
  process: ServiceProcess[];
  pricing: ServicePricing[];
}