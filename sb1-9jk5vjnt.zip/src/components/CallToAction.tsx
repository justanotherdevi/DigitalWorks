import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const CallToAction = () => {
  return (
    <section className="bg-gradient-to-r from-teal-600 to-teal-800 py-16 md:py-20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Focus on What You Do Best?</h2>
        <p className="text-white/90 max-w-2xl mx-auto mb-8 text-lg">
          Let us handle the time-consuming tasks while you focus on growing your business. 
          Our team of experts is ready to support your journey to success.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link 
            to="/contact" 
            className="px-8 py-3 rounded-md bg-white text-teal-700 font-medium hover:bg-gray-100 transition-colors inline-flex items-center justify-center"
          >
            Get Started
            <ArrowRight size={16} className="ml-2" />
          </Link>
          <Link 
            to="/services" 
            className="px-8 py-3 rounded-md bg-transparent border border-white text-white font-medium hover:bg-white/10 transition-colors inline-flex items-center justify-center"
          >
            Learn More
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;