import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="bg-gradient-to-br from-navy-900 via-navy-800 to-navy-900 text-white">
      <div className="container mx-auto px-4 pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 max-w-lg">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Your Virtual Assistance Partner
            </h1>
            <p className="text-lg text-gray-300">
              We handle the behind-the-scenes details so you can focus on growing your business. 
              From accounting to web design, we're your one-stop solution.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/services" 
                className="px-8 py-3 rounded-md bg-teal-600 text-white font-medium hover:bg-teal-700 transition-colors inline-flex items-center justify-center"
              >
                Our Services
                <ArrowRight size={16} className="ml-2" />
              </Link>
              <Link 
                to="/contact" 
                className="px-8 py-3 rounded-md bg-transparent border border-white text-white font-medium hover:bg-white/10 transition-colors inline-flex items-center justify-center"
              >
                Contact Us
              </Link>
            </div>
          </div>
          <div className="hidden md:block relative">
            <div className="relative z-10">
              <img 
                src="https://images.pexels.com/photos/3182773/pexels-photo-3182773.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Virtual Assistance Team" 
                className="rounded-lg shadow-xl object-cover h-[500px]"
              />
            </div>
            <div className="absolute top-8 -right-8 w-full h-full bg-gold-500 rounded-lg -z-0"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;