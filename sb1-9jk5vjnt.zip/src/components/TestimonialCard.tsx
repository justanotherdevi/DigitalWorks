import React from 'react';
import { Quote } from 'lucide-react';
import { Testimonial } from '../types/Testimonial';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ testimonial }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full flex flex-col">
      <div className="mb-4 text-teal-600">
        <Quote size={32} />
      </div>
      <p className="text-gray-700 mb-6 flex-grow italic">"{testimonial.quote}"</p>
      <div className="flex items-center">
        <img 
          src={testimonial.avatar} 
          alt={testimonial.name} 
          className="w-12 h-12 rounded-full object-cover mr-4"
        />
        <div>
          <h4 className="font-bold text-navy-900">{testimonial.name}</h4>
          <p className="text-sm text-gray-600">{testimonial.title}, {testimonial.company}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;