import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';
import logo from '../assets/logo.svg';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => setIsOpen(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    closeMenu();
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services', hasDropdown: true },
    { name: 'Contact', path: '/contact' },
  ];

  const services = [
    { name: 'Accounting', path: '/services/accounting' },
    { name: 'SEO', path: '/services/seo' },
    { name: 'Social Media', path: '/services/social-media' },
    { name: 'Graphic Design', path: '/services/graphic-design' },
    { name: 'Web Design', path: '/services/web-design' },
    { name: 'Project Management', path: '/services/project-management' },
  ];

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2" onClick={closeMenu}>
            <img src={logo} alt="VA Agency Logo" className="h-10" />
            <span className="text-xl font-bold text-navy-900">VirtualAssist</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <div key={link.name} className="relative group">
                {link.hasDropdown ? (
                  <button 
                    className="flex items-center text-navy-800 hover:text-teal-600 transition-colors"
                    onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                    onMouseEnter={() => setServicesDropdownOpen(true)}
                    onMouseLeave={() => setServicesDropdownOpen(false)}
                  >
                    {link.name}
                    <ChevronDown size={16} className="ml-1" />
                  </button>
                ) : (
                  <Link 
                    to={link.path}
                    className={`text-navy-800 hover:text-teal-600 transition-colors ${
                      location.pathname === link.path ? 'font-medium text-teal-600' : ''
                    }`}
                  >
                    {link.name}
                  </Link>
                )}

                {link.hasDropdown && (
                  <div 
                    className={`absolute left-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 transition-all duration-200 ${
                      servicesDropdownOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
                    }`}
                    onMouseEnter={() => setServicesDropdownOpen(true)}
                    onMouseLeave={() => setServicesDropdownOpen(false)}
                  >
                    <div className="py-1">
                      {services.map((service) => (
                        <Link
                          key={service.name}
                          to={service.path}
                          className="block px-4 py-2 text-sm text-navy-800 hover:bg-gray-100"
                        >
                          {service.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            <Link 
              to="/contact" 
              className="px-6 py-2 rounded-md bg-teal-600 text-white hover:bg-teal-700 transition-colors"
            >
              Get Started
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-navy-900" onClick={toggleMenu}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        <div 
          className={`md:hidden absolute left-0 right-0 bg-white shadow-md transition-all duration-300 ${
            isOpen ? 'max-h-screen opacity-100 visible' : 'max-h-0 opacity-0 invisible'
          } overflow-hidden`}
        >
          <div className="container mx-auto px-4 py-4">
            <nav className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <div key={link.name}>
                  {link.hasDropdown ? (
                    <div>
                      <button 
                        className="flex items-center justify-between w-full text-navy-800 hover:text-teal-600 transition-colors"
                        onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                      >
                        {link.name}
                        <ChevronDown size={16} className={`ml-1 transition-transform ${servicesDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>
                      <div className={`pl-4 mt-2 space-y-2 ${servicesDropdownOpen ? 'block' : 'hidden'}`}>
                        {services.map((service) => (
                          <Link
                            key={service.name}
                            to={service.path}
                            className="block text-navy-800 hover:text-teal-600 transition-colors"
                          >
                            {service.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <Link 
                      to={link.path}
                      className={`text-navy-800 hover:text-teal-600 transition-colors ${
                        location.pathname === link.path ? 'font-medium text-teal-600' : ''
                      }`}
                    >
                      {link.name}
                    </Link>
                  )}
                </div>
              ))}
              <Link 
                to="/contact" 
                className="px-6 py-3 rounded-md bg-teal-600 text-white hover:bg-teal-700 transition-colors text-center"
              >
                Get Started
              </Link>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;