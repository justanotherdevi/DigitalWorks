import React from 'react';
import { Shield, Clock, Users, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

const AboutSection = () => {
  const benefits = [
    {
      icon: <Shield className="w-12 h-12 text-teal-600" />,
      title: 'Trusted Expertise',
      description: 'Our team of professionals brings years of experience across multiple industries.',
    },
    {
      icon: <Clock className="w-12 h-12 text-teal-600" />,
      title: 'Time-Saving',
      description: 'We handle time-consuming tasks so you can focus on growing your business.',
    },
    {
      icon: <Users className="w-12 h-12 text-teal-600" />,
      title: 'Dedicated Team',
      description: 'A dedicated team assigned to your business, ensuring consistent quality.',
    },
    {
      icon: <Award className="w-12 h-12 text-teal-600" />,
      title: 'Quality Results',
      description: 'We deliver exceptional quality on every project, every time.',
    },
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6">Why Choose VirtualAssist?</h2>
            <p className="text-gray-600 mb-6">
              At VirtualAssist, we understand that entrepreneurs and business owners need reliable support to focus on what they do best. We're a team of dedicated professionals committed to providing exceptional virtual assistance services.
            </p>
            <p className="text-gray-600 mb-8">
              Our mission is to handle the behind-the-scenes details with precision and care, enabling you to grow your business without the burden of time-consuming tasks.
            </p>
            <Link 
              to="/about" 
              className="inline-flex items-center justify-center px-6 py-3 rounded-md bg-navy-800 text-white hover:bg-navy-900 transition-colors"
            >
              Learn More About Us
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {benefits.map((benefit, index) => (
              <div 
                key={index} 
                className="bg-white p-6 rounded-lg shadow-md border-l-4 border-teal-600 hover:shadow-lg transition-shadow"
              >
                <div className="mb-4">{benefit.icon}</div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;