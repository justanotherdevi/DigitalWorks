import React, { useState, useEffect, useRef } from 'react';

const Stats = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  
  const stats = [
    { value: 200, label: 'Happy Clients', symbol: '+' },
    { value: 5, label: 'Years of Experience', symbol: '+' },
    { value: 1000, label: 'Projects Completed', symbol: '+' },
    { value: 6, label: 'Service Categories', symbol: '' },
  ];
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }
    
    return () => {
      observer.disconnect();
    };
  }, []);
  
  return (
    <section 
      ref={sectionRef} 
      className="bg-navy-800 py-16"
    >
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat, index) => (
            <div key={index} className="p-6">
              <div className="flex items-center justify-center">
                <span 
                  className={`text-4xl md:text-5xl font-bold text-white transition-all duration-1000 ${
                    isVisible ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  {isVisible ? stat.value : 0}
                </span>
                <span className="text-4xl md:text-5xl font-bold text-teal-500 ml-1">
                  {stat.symbol}
                </span>
              </div>
              <p className="text-gray-300 mt-2">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;